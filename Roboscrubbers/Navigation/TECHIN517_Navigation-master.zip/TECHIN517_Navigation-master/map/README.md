# Note

It is recommended to use gix_map_2f.pgm and gix_map_2f.yaml as simulation map which are high-precision.