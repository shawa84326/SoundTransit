# Gazebo Simulation Model

This is GIX 2nd Floor Model for simulation using gazebo.

You can use gix-2f file.